#!/bin/bash

# 查看进程是否正在运行
#
# 参数：
# $1 UUID

ps -ef | grep $1